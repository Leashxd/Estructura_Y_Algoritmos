Despues de hacer make,
Si queremos probar la cola, ejecutar como:

./clase09 cola

Si queremos probar la pila, ejecutar como:

./clase09 pila

En cada caso para hacer un push de un numero n, ingresar:

push n

Para hacer un pop hacer:

pop 0

Para salir del programa, escribir:

quit 0
